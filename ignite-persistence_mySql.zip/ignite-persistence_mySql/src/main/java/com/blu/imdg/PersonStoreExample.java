package com.blu.imdg;

import java.util.List;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.cache.store.jdbc.CacheJdbcBlobStoreFactory;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;

import com.mysql.cj.jdbc.MysqlDataSource;

import ignite.myexamples.model.Person.Person;

public class PersonStoreExample {

	
	 public static void main(String[] args) throws IgniteException {
	        Ignition.setClientMode(true);

	        IgniteConfiguration igniteCfg = new IgniteConfiguration();

	        CacheConfiguration<Integer, Person> personCacheCfg = new CacheConfiguration<>();
	        personCacheCfg.setName("PersonCache");

	        CacheJdbcBlobStoreFactory<Integer, Person> cacheStoreFactory = new CacheJdbcBlobStoreFactory<>();

	        cacheStoreFactory.setUser("root");

	        MysqlDataSource mysqlDataSrc = new MysqlDataSource();
	        mysqlDataSrc.setURL("jdbc:mysql://localhost:3306/sample");
            mysqlDataSrc.setUser("root");
            mysqlDataSrc.setPassword("mysql");
            
	        cacheStoreFactory.setDataSource(mysqlDataSrc);

	        personCacheCfg.setCacheStoreFactory(cacheStoreFactory);

	        personCacheCfg.setWriteThrough(true);
	        personCacheCfg.setReadThrough(true);
	        
	        igniteCfg.setPeerClassLoadingEnabled(true);

	        igniteCfg.setCacheConfiguration(personCacheCfg);
	        
	        try (Ignite ignite = Ignition.start(igniteCfg)) {
	            try (IgniteCache<Long, Person> cache = ignite.getOrCreateCache("personCache")) {
	                // Load cache with data from the database.
	                cache.loadCache(null);

	                // Execute query on cache.
	                QueryCursor<List<?>> cursor = cache.query(new SqlFieldsQuery(
	                        "select id, name from person"));

	                System.out.println(cursor.getAll());
	                
	                
	            }
	        }
	    }
}
