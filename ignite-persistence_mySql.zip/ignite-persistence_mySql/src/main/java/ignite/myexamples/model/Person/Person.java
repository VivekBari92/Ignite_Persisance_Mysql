package ignite.myexamples.model.Person;

public class Person {

   
	public Person(int id, int orgId, String name, int salary) {
		super();
		this.id = id;
		this.orgId = orgId;
		this.name = name;
		this.salary = salary;
	}

	private int id;

    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrgId() {
		return orgId;
	}

	public void setOrgId(int orgId) {
		this.orgId = orgId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	private int orgId;

    private String name;

    private int salary;


  
}